import 'react-native-gesture-handler';
import * as React from 'react';

import { Button } from 'react-native';

import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import LoadingScreen from './src/screens/loading';
import Chat from './src/screens/chat';
import Home from './src/screens/home';
import SearchResources from './src/screens/resources-search';
import AddResource from './src/screens/resource-add';
import EditResource from './src/screens/resource-edit';
import MyResources from './src/screens/resources-my';
import AddLand from './src/screens/land-add';
import EditLand from './src/screens/land-edit';
import MyLands from './src/screens/lands-my';
import Add from './src/screens/add';
import Edit from './src/screens/edit';
import Vendors from './src/screens/vendors';
import Map from './src/screens/map';
import AddPreBook from './src/screens/order-add';
import EditPreBook from './src/screens/order-edit';
import MyPreBooks from './src/screens/orders-my';

import { HomeIcon, DonateIcon, SearchIcon } from './src/images/svg-icons';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

const ResourcesStackOptions = ({ navigation }) => {
  return ({
    headerRight: () => (
      <Button
        onPress={() => navigation.navigate('Chat')}
        title='Chat '
        color='green'
      />
    )
  });
};

const DonationsStackOptions = ({ navigation }) => {
  return ({
    headerRight: () => (
      <Button
        onPress={() => navigation.navigate('Add Crop')}
        title='Add '
        color='green'
      />
    )
  });
};

const LandStackOptions = ({ navigation }) => {
  return ({
    headerRight: () => (
      <Button
        onPress={() => navigation.navigate('Add Land')}
        title='Add '
        color='green'
      />
    )
  });
};


const PreBookStackOptions = ({ navigation }) => {
  return ({
    headerRight: () => (
      <Button
        onPress={() => navigation.navigate('PreBook')}
        title='Add '
        color='green'
      />
    )
  });
};

const VendorStackOptions = ({ navigation }) => {
  return ({
    headerRight: () => (
      <Button
        onPress={() => navigation.navigate('Add')}
        title='Add '
        color='green'
      />
    )
  });
};

const tabBarOptions = {
  // showLabel: false,
  activeTintColor: 'green',
  inactiveTintColor: '#000',
  style: {
    backgroundColor: '#F1F0EE',
    paddingTop: 5
  }
};

const TabLayout = () => (
  <Tab.Navigator
    style={{paddingTop: 50}}
    initialRouteName='Home'
    tabBarOptions={tabBarOptions} >
    <Tab.Screen
      name='Home'
      component={Home}
      options={{
        tabBarIcon: ({color}) => (<HomeIcon fill={color}/>)
      }}
    />
    <Tab.Screen
      name='Crops'
      component={DonateStackLayout}
      options={{
        tabBarIcon: ({color}) => (<DonateIcon fill={color} />)
      }}
    />
    <Tab.Screen
      name='Land Details'
      component={LandStackLayout}
      options={{
        tabBarIcon: ({color}) => (<DonateIcon fill={color} />)
      }}
    />
   
    <Tab.Screen
      name='Vendor'
      component={VendorStackLayout}
      options={{
        tabBarIcon: ({color}) => (<DonateIcon fill={color} />)
      }}
    />

    <Tab.Screen
      name='PreBook'
      component={PreBookStackLayout}
      options={{
        tabBarIcon: ({color}) => (<DonateIcon fill={color} />)
      }}
    />

    <Tab.Screen
      name='Search'
      component={SearchStackLayout}
      options={{
        tabBarIcon: ({color}) => (<SearchIcon fill={color} />)
      }}
    />
  </Tab.Navigator>
);

const DonateStackLayout = () => (
  <Stack.Navigator>
  <Stack.Screen name='My Crops' component={MyResources} options={DonationsStackOptions} />
    <Stack.Screen name='Add Crop' component={AddResource} />
    <Stack.Screen name='Edit Crop' component={EditResource} />
  </Stack.Navigator>
);

const LandStackLayout = () => (
  <Stack.Navigator>
  <Stack.Screen name='My Lands' component={MyLands} options={LandStackOptions} />
    <Stack.Screen name='Add Land' component={AddLand} />
    <Stack.Screen name='Edit Land' component={EditLand} />
  </Stack.Navigator>
);

const PreBookStackLayout = () => (
  <Stack.Navigator>
  <Stack.Screen name='My PreBookings' component={MyPreBooks} options={PreBookStackOptions} />
    <Stack.Screen name='PreBook' component={AddPreBook} />
    <Stack.Screen name='Edit PreBooking' component={EditPreBook} />
  </Stack.Navigator>
);

const VendorStackLayout = () => (
  <Stack.Navigator>
    <Stack.Screen name='Vendors' component={Vendors} options={VendorStackOptions} />
    <Stack.Screen name='Add' component={Add} />
    <Stack.Screen name='Edit' component={Edit} />
  </Stack.Navigator>
);

const SearchStackLayout = () => (
  <Stack.Navigator>
    <Stack.Screen name='Search Resources' component={SearchResources} options={ResourcesStackOptions} />
    <Stack.Screen name='Chat' component={Chat} />
    <Stack.Screen name='Map' component={Map} />
  </Stack.Navigator>
);

const App = () => {
  const [isLoading, setIsLoading] = React.useState(true);


  React.useEffect(() => {
    setTimeout(() => {
      setIsLoading(false);
    }, 500);
  }, []);

  if (isLoading) {
    return (<LoadingScreen />);
  } else {
    return (
      <NavigationContainer>
        <TabLayout/>
      </NavigationContainer>
    );
  }
};

export default App;
