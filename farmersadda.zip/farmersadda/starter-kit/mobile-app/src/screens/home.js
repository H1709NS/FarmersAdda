import React from 'react';
import { StyleSheet, View, Text, TouchableOpacity } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import { ImageBackground } from "react-native";

const styles = StyleSheet.create({
  center: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
    backgroundColor: '#FFFFFF'
  },
  scroll: {
    paddingLeft: 20,
    paddingRight: 20,
    paddingBottom: 25,
    paddingTop: 75
  },
  image: {
    alignSelf: 'flex-start',
    height: '100%',
    width:'50%',
    resizeMode: 'contain'
  },
  title: {
    fontFamily: 'IBMPlexSans-Medium',
    fontSize: 36,
    color: 'black',
    paddingBottom: 15
  },
  subtitle: {
    fontFamily: 'IBMPlexSans-Light',
    fontSize: 24,
    color: '#323232',
    textDecorationColor: 'green',
    textDecorationLine: 'underline',
    paddingBottom: 5,
    paddingTop: 20
  },
  content: {
    fontFamily: 'IBMPlexSans-Medium',
    color: 'black',
    marginTop: 10,
    marginBottom: 10,
    fontSize: 18
  },
  buttonGroup: {
    flex: 1,
    paddingTop: 15,
    width: 175
  },
  button: {
    backgroundColor: 'green',
    color: 'black',
    fontFamily: 'IBMPlexSans-Medium',
    fontSize: 16,
    overflow: 'hidden',
    padding: 12,
    textAlign:'center',
    marginTop: 15
  }
});

const Home = function ({ navigation }) {
  
  return (
  <View style={styles.center}>
    <ImageBackground
        style={{width: '100%', height: '100%'}}
        source={require('../images/crop-7.jpg')}
        > 
    <ScrollView style={styles.scroll}>
      <Text style={styles.title}>FARMER'S ADDA</Text>
      <Text style={styles.content}>
        A community cooperation app for Farmer empowerment and to solve problems in times of crisis, whether it be to
        advertise where supplies are held or offer assistance for collections by eliminating middlemen.
      </Text>
      <View style={styles.buttonGroup}>
        <TouchableOpacity onPress={() => { navigation.navigate('Crops')}}>
          <Text style={styles.button}>Farmer</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => { navigation.navigate('Vendors')}}>
          <Text style={styles.button}>Merchant</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => { navigation.navigate('Vendors')}}>
          <Text style={styles.button}>Transport Vendor</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
    </ImageBackground>
  </View>
  );
}

export default Home;
